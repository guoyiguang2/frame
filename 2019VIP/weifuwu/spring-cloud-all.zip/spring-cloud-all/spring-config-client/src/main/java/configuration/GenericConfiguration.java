package configuration;

public class GenericConfiguration {

    public static void main(String[] args) {

        println(System.getProperty("user.home"));

        println(System.getProperty("user.age", "0"));
        // 将 System Properties 转换为 Integer 类型
        println(Integer.getInteger("user.age", 0));
        println(Boolean.getBoolean("user.male"));
    }

    private static void println(Object object) {
        System.out.println(object);
    }

}
